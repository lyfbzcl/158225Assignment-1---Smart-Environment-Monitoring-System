/* Fetch /api/latest every second and update DOM + chart */
function fetchLatestData () {
  fetch('/api/latest')
    .then(r => r.json())
    .then(data => {
      if (data.error) {
        console.error('Latest data fetch error:', data.error);
        return;
      }

      /* ---- text fields ---- */
      document.getElementById('timestamp'     ).innerText = data.timestamp   || '--:--:--';
      document.getElementById('temp-value'    ).innerText = data.temperature ?? '--';
      document.getElementById('humidity-value').innerText = data.humidity    ?? '--';
      document.getElementById('pressure-value').innerText = data.pressure    ?? '--';

      /* status badges */
      const OK    = 'OK';
      const ALERT = 'ALERT ⚠';
      document.getElementById('temp-status'    ).innerText = data.temp_alert     ? ALERT : OK;
      document.getElementById('humidity-status').innerText = data.humidity_alert ? ALERT : OK;
      document.getElementById('pressure-status').innerText = data.pressure_alert ? ALERT : OK;

      document.getElementById('temp-status'    ).className = data.temp_alert     ? 'alert' : 'normal';
      document.getElementById('humidity-status').className = data.humidity_alert ? 'alert' : 'normal';
      document.getElementById('pressure-status').className = data.pressure_alert ? 'alert' : 'normal';

      /* ---- live chart ---- */
      const timeLabel = data.timestamp.split(' ')[1]; // HH:MM:SS

      if (realtimeChart.data.labels.length >= 20) {
        realtimeChart.data.labels.shift();
        realtimeChart.data.datasets.forEach(ds => ds.data.shift());
      }

      realtimeChart.data.labels.push(timeLabel);
      realtimeChart.data.datasets[0].data.push(data.temperature);
      realtimeChart.data.datasets[1].data.push(data.humidity);
      realtimeChart.data.datasets[2].data.push(data.pressure);
      realtimeChart.update();
    })
    .catch(err => console.error('Fetch error:', err));
}

/* kick off polling once page has loaded */
setInterval(fetchLatestData, 1000);
