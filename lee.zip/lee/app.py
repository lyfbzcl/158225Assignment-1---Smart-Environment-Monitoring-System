import sqlite3, threading, time
from datetime import datetime
from flask import Flask, request, jsonify, render_template

# ---------- Sense HAT / emulator ----------
try:
    from sense_emu import SenseHat
except ImportError:
    try:
        from sense_hat import SenseHat
    except ImportError:
        SenseHat = None

# ---------- Globals ----------
last_reading = {}
threshold_values = {
    'temp':     {'min': -30.0, 'max': 100.0},
    'humidity': {'min':   0.0, 'max': 100.0},
    'pressure': {'min': 500.0, 'max': 1300.0}
}
app = Flask(__name__)

# ---------- DB init ----------
def init_db():
    conn = sqlite3.connect('environment.db'); cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS data (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     timestamp TEXT,
                     temperature REAL, humidity REAL, pressure REAL)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS thresholds (
                     param TEXT PRIMARY KEY, min REAL, max REAL)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS alerts (
                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                     timestamp TEXT, type TEXT,
                     param TEXT, value REAL, message TEXT)""")
    if cur.execute("SELECT COUNT(*) FROM thresholds").fetchone()[0] == 0:
        for p in threshold_values:
            cur.execute("INSERT INTO thresholds VALUES (?,?,?)",
                        (p, threshold_values[p]['min'], threshold_values[p]['max']))
    else:
        for p, mn, mx in cur.execute("SELECT param,min,max FROM thresholds"):
            threshold_values[p]['min'] = float(mn); threshold_values[p]['max'] = float(mx)
    conn.commit(); conn.close()

# ---------- Helpers ----------
def param_display(p):
    return 'Temperature' if p=='temp' else 'Humidity' if p=='humidity' else 'Pressure'

colour_map = {'temp':[255,0,0], 'humidity':[0,0,255], 'pressure':[0,255,0]}

def led_alert(sense, param, message):
    """Scroll message on LED matrix in colour based on parameter."""
    if not sense:        # 无硬件/模拟器
        return
    try:
        sense.low_light = True
        sense.show_message(message[:8], text_colour=colour_map.get(param,[255,255,255]),
                           scroll_speed=0.05)
    except Exception:
        pass

# ---------- Sensor thread ----------
def sensor_loop():
    conn = sqlite3.connect('environment.db', check_same_thread=False)
    cur  = conn.cursor()
    sense = SenseHat() if SenseHat else None

    history = {'temp': [], 'humidity': [], 'pressure': []}
    trend   = {'temp': None, 'humidity': None, 'pressure': None}
    trig    = {'temp': False,'humidity': False,'pressure': False}
    spike_th = {'temp': 2.0, 'humidity': 5.0, 'pressure': 10.0}

    while True:
        if not sense:
            time.sleep(1); continue

        t = sense.get_temperature(); h = sense.get_humidity(); p = sense.get_pressure()
        ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # store raw data
        try:
            cur.execute("INSERT INTO data(timestamp,temperature,humidity,pressure) VALUES (?,?,?,?)",
                        (ts, t, h, p)); conn.commit()
        except Exception as e:
            conn.rollback(); print('[DB error]', e)

        last_reading.update({'timestamp':ts,'temperature':round(t,2),
                             'humidity':round(h,2),'pressure':round(p,2)})

        # maintain history
        for n,v in [('temp',t),('humidity',h),('pressure',p)]:
            buf = history[n]; buf.append(v);  buf[:] = buf[-5:]

        events = []

        # Spike
        for n,v in [('temp',t),('humidity',h),('pressure',p)]:
            buf = history[n]
            if len(buf)>=2 and abs(buf[-1]-buf[-2])>spike_th[n]:
                events.append((n,'SPIKE',v,f'{param_display(n)} sudden {"rise" if buf[-1]>buf[-2] else "drop"}'))

        # Trend + Projection
        for n,buf in history.items():
            if len(buf)<5: continue
            latest=buf[-1]; param=param_display(n)
            if all(x<y for x,y in zip(buf,buf[1:])):               # upward
                if trend[n]!='up':
                    trend[n]='up'
                    events.append((n,'TREND',latest,f'{param} trending upward'))
                slope=(buf[-1]-buf[0])/4; proj=buf[-1]+slope*5
                if proj>threshold_values[n]['max']:
                    events.append((n,'PREDICTION',latest,
                                   f'Projection: {param.lower()} may exceed upper limit {threshold_values[n]["max"]:.2f} soon'))
            elif all(x>y for x,y in zip(buf,buf[1:])):             # downward
                if trend[n]!='down':
                    trend[n]='down'
                    events.append((n,'TREND',latest,f'{param} trending downward'))
                slope=(buf[-1]-buf[0])/4; proj=buf[-1]+slope*5
                if proj<threshold_values[n]['min']:
                    events.append((n,'PREDICTION',latest,
                                   f'Projection: {param.lower()} may drop below lower limit {threshold_values[n]["min"]:.2f} soon'))
            else:
                trend[n]=None

        # Threshold breach
        for n,v in [('temp',t),('humidity',h),('pressure',p)]:
            mn=threshold_values[n]['min']; mx=threshold_values[n]['max']
            if v<mn or v>mx:
                if not trig[n]:
                    trig[n]=True
                    msg=(f'{param_display(n)} below lower limit: {v:.2f} < {mn:.2f}'
                         if v<mn else
                         f'{param_display(n)} above upper limit: {v:.2f} > {mx:.2f}')
                    events.append((n,'THRESHOLD',v,msg))
            else:
                trig[n]=False

        # write alerts + LED
        if events:
            try:
                cur.executemany("INSERT INTO alerts(timestamp,type,param,value,message) VALUES (?,?,?,?,?)",
                                [(ts, typ, param, val, msg) for param, typ, val, msg in events])
                conn.commit()
            except:
                conn.rollback()

            # scroll each message on LED
            for param, typ, val, msg in events:
                led_alert(sense, param, msg)

        time.sleep(1)

# ---------- Routes ----------
@app.route('/')
def realtime_page():
    return render_template('realtime.html')

@app.route('/api/latest')
def api_latest():
    if not last_reading:
        return jsonify({'error':'No data available'}),503
    t=last_reading['temperature']; h=last_reading['humidity']; p=last_reading['pressure']
    return jsonify({
        'timestamp':last_reading['timestamp'],
        'temperature':t,'humidity':h,'pressure':p,
        'temp_alert':t<threshold_values['temp']['min'] or t>threshold_values['temp']['max'],
        'humidity_alert':h<threshold_values['humidity']['min'] or h>threshold_values['humidity']['max'],
        'pressure_alert':p<threshold_values['pressure']['min'] or p>threshold_values['pressure']['max']
    })

@app.route('/history')
def history_page():
    conn=sqlite3.connect('environment.db'); cur=conn.cursor()
    cur.execute("SELECT timestamp,temperature,humidity,pressure FROM data ORDER BY id")
    rows=cur.fetchall(); conn.close()
    times=[r[0] for r in rows]; temps=[round(r[1],2) for r in rows]
    hums=[round(r[2],2) for r in rows]; pres=[round(r[3],2) for r in rows]
    return render_template('history.html',
                           labels=times,temp_data=temps,
                           humidity_data=hums,pressure_data=pres)

@app.route('/threshold',methods=['GET','POST'])
def threshold_page():
    if request.method=='POST':
        try:
            tmin=float(request.form['temp_min']); tmax=float(request.form['temp_max'])
            hmin=float(request.form['humidity_min']); hmax=float(request.form['humidity_max'])
            pmin=float(request.form['pressure_min']); pmax=float(request.form['pressure_max'])
        except ValueError:
            return render_template('threshold.html',thresholds=threshold_values,
                                   error='Please enter valid numbers.')
        if tmin>tmax:tmin,tmax=tmax,tmin
        if hmin>hmax:hmin,hmax=hmax,hmin
        if pmin>pmax:pmin,pmax=pmax,pmin
        conn=sqlite3.connect('environment.db'); cur=conn.cursor()
        for p,lo,hi in [('temp',tmin,tmax),('humidity',hmin,hmax),('pressure',pmin,pmax)]:
            cur.execute("UPDATE thresholds SET min=?,max=? WHERE param=?",(lo,hi,p))
            threshold_values[p]['min']=lo; threshold_values[p]['max']=hi
        conn.commit(); conn.close()
        return render_template('threshold.html',thresholds=threshold_values,
                               success='Thresholds updated successfully!')
    return render_template('threshold.html',thresholds=threshold_values)

@app.route('/alerts')
def alerts_page():
    conn=sqlite3.connect('environment.db'); cur=conn.cursor()
    cur.execute("SELECT timestamp,type,param,value,message FROM alerts ORDER BY id")
    alerts=[{'timestamp':r[0],'type':r[1],'param':r[2],'value':r[3],'message':r[4]} for r in cur.fetchall()]
    conn.close()
    return render_template('alerts.html',alerts=alerts)

# ---------- Boot ----------
if __name__=='__main__':
    init_db()
    threading.Thread(target=sensor_loop,daemon=True).start()
    app.run(host='0.0.0.0',port=5000)

